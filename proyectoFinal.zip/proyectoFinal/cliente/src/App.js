// Dependencias generales
import React from "react";
import {Routes,Route} from 'react-router-dom';
import registrarse from './hotel/registrarse';

// Función del router
function App() {
  return (
    <div>
        <Routes>
            <Route path="/" Component={registrarse}>
            </Route>        
        </Routes>
    </div>
  );    
}
export default App;