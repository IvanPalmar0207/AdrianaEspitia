// Dependencias generales
import React from "react";
import {Routes,Route} from 'react-router-dom';
import registrarse from './hotel/registrarse';
import iniciarSesion  from "./hotel/iniciarSesion";
import Layout from './hotel/Layout';
import home from './hotel/home';
import reservar from './hotel/reservar';

// Función del router
function App() {
  return (
    <div>
        <Routes>
            <Route path="/" Component={Layout}>
                <Route path="/home" Component={home}></Route>
                <Route path="/registrarse" Component={registrarse}></Route>
                <Route path="/iniciarSesion" Component={iniciarSesion}></Route>
                <Route path="/reservar" Component={reservar}></Route>                                      
            </Route>      
        </Routes>
    </div>
  );    
}
export default App;