//Importa los estilos para el archivo app.js
import './css/registrarse.css';
//Importa useState de React para manipular los datos del formulario
import{useState} from 'react';
//Importa la libreria Axios
import Axios from 'axios';
//importa Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css'
//Importa SweetAlert2
import Swal from 'sweetalert2';
//Importa los estilos
import reserva from './css/reserva.css';


const Reservar = () => {
  
    //Datos y su estado
    const [fechaLLegada_res, setfechaLegada] = useState("");
    const [fechaSalida_res, setFechaSalida] = useState("");
    const [numeroDocumento_usu,setNumeroDocumento] = useState("");
    const [cantidadAdultos_res,setCantidadAultos] = useState("");
    const [cantidadNinos_res,setCantidadNinos] = useState("");
    const [email_usu,setEmail] = useState("");
    //Estado de la actualizacion
    const [editarReservas,setEditarReservas] = useState(false);
    //Estado de la consulta
    const [usuariosList,setUsuarios] = useState([]);

    //Metodo de registe ro

    const registrarReserva = () =>{
        Axios.post("http://localhost:3001/createReserva",{
            fechaLLegada_res: fechaLLegada_res,
            fechaSalida_res: fechaSalida_res,
            numeroDocumento_usu: numeroDocumento_usu,
            cantidadAdultos_res: cantidadAdultos_res,
            cantidadNinos_res: cantidadNinos_res,
            email_usu: email_usu            
        }).then(()=>{
            listar();
            limpiar();
            Swal.fire({
                title:"<strong> Registro exitoso! </strong>",
                html:"<i>La reserva asociada al numero de documento:<strong>" +numeroDocumento_usu+ "</strong> fue realizada con exito! </i>",
                icon: "success",
                timer: 3000
            })
        }).catch(function(error){
            Swal.fire({
                icon: "error",
                title: 'Oops...',
                text: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
            })
        });
    }

    //Metodo para actualizar

    const updateReserva = () =>{
        Axios.put('http://localhost:3001/updateReservas',{
            fechaLLegada_res: fechaLLegada_res,
            fechaSalida_res: fechaSalida_res,
            numeroDocumento_usu: numeroDocumento_usu,
            cantidadAdultos_res: cantidadAdultos_res,
            cantidadNinos_res: cantidadNinos_res,
            email_usu: email_usu
        }).then(() => {
        
            listar();
            limpiar();
        
            Swal.fire({
                title: '<strong>La actualizacion ha sido existosa</strong>',
                html: '<i>La  reserva fue actualizada con exito!!!</i>',
                icon: 'success',
                timer:3000
            })
        }).catch(function(error){
            Swal.fire({
                icon:'error',
                title:'Oops..',
                text: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
            })
        });
    }


    //Metodo de lectura

    const listarReserva = () => {
        Axios.get('http://localhost:3001/reservas').then((response) => {
            setUsuarios(response.data);
        })
    }

    //Metodo de Eliminacion 

    const deleteReserva = (val) => {
        Swal.fire({
            title:'Confirmar eliminacion?',
            html:'<i>Realmente desea eliminar la reserva</i>',
            icon:'warning',
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor:"#d33",
            confirmButtonText: "Si, eliminarlo¡"
        }).then((result)=>{
            if(result.isConfirmed){
                Axios.delete(`http://localhost:3001/deleteReserva/${val.numeroDocumento_usu}`).then((res)=>{
                
                    listar();
                    limpiar();
                
                Swal.fire({
                    icon:'success',
                    title: "La reserva fue eliminada",
                    showConfirmButton: false,
                    timer: 2000
                });
               }).catch(function(error){
                Swal.fire({
                    icon:'error',
                    title:'Oops...',
                    text: 'No se logro eliminar al usuario',
                    footer: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
                })
               });
            }
        });
    }

    //Limpiar los formularios

    const limpiar = () => {
        setfechaLegada("");
        setFechaSalida("");
        setNumeroDocumento("");
        setCantidadAultos("");
        setCantidadNinos("");
        setEmail("");        
        setEditarReservas(false);
    }

    //Pasar datos a actualizar al formulario

    const editarReserva = (val) => {
        setEditarReservas(true);
        setfechaLegada(val.fechaLLegada_res);
        setFechaSalida(val.fechaSalida_res);
        setNumeroDocumento(val.numeroDocumento_usu);
        setCantidadAultos(val.cantidadAdultos_res);
        setCantidadNinos(val.cantidadNinos_res);
        setEmail(val.email_usu);    
    }

    //Metodo de lectura

    const listar = () => {
        Axios.get('http://localhost:3001/reservas').then((response)=>{
            setUsuarios(response.data);
        });
    }

    //Interfaz de usuario

    return (      
    <div className="App">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"/>
        <link rel='stylesheet' href={reserva}></link>

      <section id="reserva" className="bloque">
          <div className="contenido">
              <div className="formulario">
                  <div className='form'>

                      <h2>RESERVAR - SENA</h2>

                      <div className="info">
                          <label>Fecha de llegada:</label>
                          <input type="date" name="fechaLlegada" id="fechaLlegada" onChange={(event) => {setfechaLegada(event.target.value);}} value={fechaLLegada_res} required/>
                      </div>

                      <div className="info">
                          <label>Fecha de Salida:</label>
                          <input type="date" name="fechaSalida" id="fechaSalida" onChange={(event) => {setFechaSalida(event.target.value);}} value={fechaSalida_res} required/>
                      </div>


                      <div className="info">
                          <label>Numero de documento:</label>
                          <input type="text" name="numeroDocumento" id="numeroDocumento" onChange={(event) => {setNumeroDocumento(event.target.value);}} value={numeroDocumento_usu} required/>
                      </div>

                      <div className="info">
                          <label>Cantidad de Adultos:</label>
                          <input type="text" name="cantidadAdultos" id="cantidadAdultos" onChange={(event) => {setCantidadAultos(event.target.value);}} value={cantidadAdultos_res} required/>
                      </div>

                      <div className="info">
                          <label>Cantidad de niños:</label>
                          <input type="text" name="cantidadNiños" id="cantidadNiños" onChange={(event) => {setCantidadNinos(event.target.value);}} value={cantidadNinos_res} required/>
                      </div>

                      <div className="info">
                          <label>Correo Electronico:</label>
                          <input type="email" name="email" id="email" onChange={(event) => {setEmail(event.target.value);}} value={email_usu} required/>
                      </div>

                      <div className="info">
                          <input className="box" type="checkbox"/><span>He leido y acepto los terminos</span>
                      </div>                                 
                      <div className='card-footer text-muted infoBoton'>
                    {
                        editarReservas?
                        <div className='infoBTN'>
                            <button className='btn btn-warning m2 btnEnviar' onClick={updateReserva}>Actualizar</button>
                            <button className='btn btnEnviarC' onClick={limpiar}>Cancelar</button>                        
                        </div>
                        :<button className="btnEnviar" onClick = {registrarReserva}>Reservar</button>

                    }
                        <button className='btn btn-secondary btnEnviar listar' onClick={listarReserva}>Listar</button>
            </div> 
                </div>
            </div>  
          </div>
      </section>

      <div className='lista'>
        <table className='table table-striped'>
            <thead>
                <tr>                
                    <th scope='col'>Fecha de llegada:</th>
                    <th scope='col'>Fecha de Salida:</th>
                    <th scope='col'>Numero de documento</th>
                    <th scope='col'>Cantidad de adultos:</th>
                    <th scope='col'>Cantidad de niños:</th>
                    <th scope='col'>Correo Electronico:</th>                    
                    <th scope='col'>Acciones:</th>
                </tr>
            </thead>
            <tbody>       
        
                    {   
                        usuariosList.map((val,key)=>{
                        return <tr key={val.numeroDocumento_usu}>
                                    <td>{val.fechaLLegada_res}</td>
                                    <td>{val.fechaSalida_res}</td>
                                    <th>{val.numeroDocumento_usu}</th>
                                    <td>{val.cantidadAdultos_res}</td>
                                    <td>{val.cantidadNinos_res}</td>
                                    <td>{val.email_usu}</td>
                                   <td>
                                        <div className='btn-group' role='group' aria-label='Basic Example'>
                                            <button type='button'
                                            onClick={()=>{
                                                editarReserva(val);
                                            }} className='btn btn-warning'>Actualizar</button>
                                            <button type='button' className='btn btn-danger' onClick={()=>{
                                            deleteReserva(val);
                                            }}>Eliminar</button>
                                        </div>
                                    </td>
                                </tr>
                        })                
                    }

            </tbody>
        </table>
      </div>
      
    
      <footer className="d-flex flex-column align-items-center justify-content-center">
          <p className="footer-texto text-center">El SENA quiere brindarte la mejor estadia.
              <br/>Ven, comparte y disfruta en nuestro Hotel.</p>
          <div className="iconos-redes-sociales d-flex flex-wrap align-items-center justify-content-center">
              <a href="https://web.facebook.com/sena.soacha/?locale=es_LA&_rdc=1&_rdr" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-facebook"></i>
              </a>
              <a href="https://twitter.com/SENASoacha?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-twitter"></i>
              </a>
              <a href="https://senasoachacide.blogspot.com/" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-mortarboard-fill"></i>
              </a>
              <a href="mailto:servicioalciudadano@sena.edu.co " target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-envelope"></i>
              </a>
          </div>
          <div className="derechos-de-autor">Creado por: Centro Industrial y de Desarrollo Empresarial &#169;</div> 
      </footer>
    </div>
  );
}

export default Reservar;
