//Importa los estilos para el archivo app.js
import '../App.css';
//Importa useState de React para manipular los datos del formulario
import{useState} from 'react';
//Importa la libreria Axios
import Axios from 'axios';
//importa Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css'
//Importa SweetAlert2
import Swal from 'sweetalert2';
import { Link } from 'react-router-dom';
//Importa los ruteos para la nevegacion
import App from '../App';
import {Routes,Route} from 'react-router-dom';
import iniciarSesion from "./iniciarSesion";


function Regristrate() {
  
    //Datos y su estado
    const [numeroDocumento_usu, setNumeroDocumento] = useState("");
    const [nombreUsuario_usu, setUsuario] = useState("");
    const [nombre_usu,setNombre] = useState("");
    const [apellido_usu,setApellido] = useState("");
    const [email_usu,setEmail] = useState("");
    const [constrasena_usu,setContrasena] = useState("");
    const [codigo_tpU, setTipoUsuario] = useState("3");
    const [usuariosList,setUsuarios] = useState([]);
    const [editar,setEditar] = useState(false);

    //Metodo de registro

    const registrarUsuario = () =>{
        Axios.post("http://localhost:3001/create",{
            numeroDocumento_usu: numeroDocumento_usu,
            nombreUsuario_usu: nombreUsuario_usu,
            nombre_usu: nombre_usu,
            apellido_usu: apellido_usu,
            email_usu: email_usu,
            constrasena_usu: constrasena_usu,
            codigo_tpU: codigo_tpU
        }).then(()=>{
            listar();
            limpiar();
            Swal.fire({
                title:"<strong> Registro exitoso! </strong>",
                html:"<i>El usuario <strong>" +nombreUsuario_usu + "</strong> fue registrado con exito! </i>",
                icon: "success",
                timer: 3000
            })
        }).catch(function(error){
            Swal.fire({
                icon: "error",
                title: 'Oops...',
                text: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
            })
        });
    }

    //Metodo para actualizar

    const updateUsuario = () =>{
        Axios.put('http://localhost:3001/updateUsuarios',{
            numeroDocumento_usu: numeroDocumento_usu,
            nombreUsuario_usu: nombreUsuario_usu,
            nombre_usu: nombre_usu,
            apellido_usu: apellido_usu,
            email_usu: email_usu,
            constrasena_usu: constrasena_usu,
            codigo_tpU: codigo_tpU
        }).then(() => {
        
            listar();
            limpiar();
        
            Swal.fire({
                title: '<strong>La actualizacion ha sido existosa</strong>',
                html: '<i> El usuario <strong>' +nombreUsuario_usu+"'</strong> fue actualizado con exito!!!</i>",
                icon: 'success',
                timer:3000
            })
        }).catch(function(error){
            Swal.fire({
                icon:'error',
                title:'Oops..',
                text: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
            })
        });
    }

    const editarUsuario = (val)=>{
        setEditar(true);
        setNumeroDocumento(val.numeroDocumento_usu);
        setUsuario(val.nombreUsuario_usu);
        setNombre(val.nombre_usu);
        setApellido(val.apellido_usu);
        setEmail(val.email_usu);
        setContrasena(val.constrasena_usu);
    }

    const listarUsuario = () => {
        Axios.get('http://localhost:3001/usuarios').then((response) => {
            setUsuarios(response.data);
        })
    }

    const deleteUsuario = (val) => {
        Swal.fire({
            title:'Confirmar eliminacion?',
            html:'<i>Realmente desea eliminar a <strong>'+val.nombreUsuario_usu+'</strong>?</i>',
            icon:'warning',
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor:"#d33",
            confirmButtonText: "Si, eliminarlo¡"
        }).then((result)=>{
            if(result.isConfirmed){
                Axios.delete(`https://localhost:3001/delete/${val.numeroDocumento_usu}`).then((res)=>{
                {/*
                    listar();
                    limpiar();
                */}
                Swal.fire({
                    icon:'success',
                    title: val.nombre_usu + 'fue eliminado.',
                    showConfirmButton: false,
                    timer: 2000
                });
               }).catch(function(error){
                Swal.fire({
                    icon:'error',
                    title:'Oops...',
                    text: 'No se logro eliminar al usuario',
                    footer: JSON.parse(JSON.stringify(error)).message==="Network Error"?"Intente mas tarde":JSON.parse(JSON.stringify(error)).message
                })
               });
            }
        });
    }

    //Limpiar los formularios

    const limpiar = () => {
        setNumeroDocumento("");
        setUsuario("");
        setNombre("");
        setApellido("");
        setEmail("");
        setContrasena("");        
        setEditar(false);
    }

    //Pasar datos a actualizar al formulario

    const editarUsu = (val) => {
        setEditar(true);
        setNumeroDocumento(val.numeroDocumento_usu);
        setUsuario(val.nombreUsuario_usu);
        setNombre(val.nombre_usu);
        setApellido(val.apellido_usu);
        setEmail(val.email_usu);
        setContrasena(val.constrasena_usu);
        setTipoUsuario(val.codigo_tpU);
    }

    //Metodo de lectura

    const listar = () => {
        Axios.get('http://localhost:3001/usuarios').then((response)=>{
            setUsuarios(response.data);
        });
    }

    return (      
    <div className="App">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"/>

    <div>
        <Routes>
            <Route path="/App" Component={App}>
            </Route>                  
        </Routes>
    </div>

      <section id="registro" className="bloque">
          <div className="contenido">
              <div className="formulario">
                  <div className='form'>

                      <h2>Registrate en el SENA</h2>

                      <div className="info">
                          <label>Nro.Documento:</label>
                          <input type="text" name="numeroDocumento" id="numeroDocumento" onChange={(event) => {setNumeroDocumento(event.target.value);}} value={numeroDocumento_usu}/>
                      </div>

                      <div className="info">
                          <label>Ingresa tu usuario:</label>
                          <input type="text" name="nombreUsuario" id="nombreUsuario" onChange={(event) => {setUsuario(event.target.value);}} value={nombreUsuario_usu}/>
                      </div>


                      <div className="info">
                          <label>Ingresa tus nombre/s:</label>
                          <input type="text" name="nombre" id="nombre" onChange={(event) => {setNombre(event.target.value);}} value={nombre_usu}/>
                      </div>

                      <div className="info">
                          <label>Ingresa tus apellidos:</label>
                          <input type="text" name="apellido" id="apellido" onChange={(event) => {setApellido(event.target.value);}} value={apellido_usu}/>
                      </div>

                      <div className="info">
                          <label>Ingresa tu email:</label>
                          <input type="email" name="email" id="email" onChange={(event) => {setEmail(event.target.value);}} value={email_usu}/>
                      </div>

                      <div className="info">
                          <label>Ingresa tu contraseña:</label>
                          <input type="password" name="contrasena" id="contrasena" onChange={(event) => {setContrasena(event.target.value);}} value={constrasena_usu}/>
                      </div>

                      <div className="info">
                          <label>Tipo de Usuario</label>
                          <input disabled={true} type="text" name="usuario" id="usuario" onChange={(event) => {setTipoUsuario(event.target.value='3');}} value={codigo_tpU}/>
                      </div>

                      <div className="info">
                          <input className="box" type="checkbox"/><span>He leido y acepto las condiciones</span>
                      </div>

                      <div className="info">
                          <button className="btnEnviar" onClick = {registrarUsuario}>Enviar</button>
                      </div>
                      
                      <div className="info">
                          <button className="btnEnviar listar" onClick = {listarUsuario}>Listar</button>
                      </div>

                      <div className="info">
                          <button className="btnEnviar actualizar" onClick = {updateUsuario}>Actualizar</button>
                      </div>
                  </div>                
            </div>

            <div className='card-footer text-muted'>
                {
                    editar?
                    
                }
            </div>

          </div>
      </section>

      <div className='lista'>
        <table className='table table-striped'>
            <thead>
                <tr>
                    <th scope='col'>Numero de Documento:</th>
                    <th scope='col'>Nombre de usuario:</th>
                    <th scope='col'>Nombre/s:</th>
                    <th scope='col'>Apellidos:</th>
                    <th scope='col'>Email:</th>
                    <th scope='col'>Constraseña:</th>
                </tr>
            </thead>
            <tbody>       
                
                         
                        usuariosList.map{(val,key)=>{
                        return <tr key={val.numeroDocumento_usu}>
                                    <td>{val.nombreUsuario_usu}</td>
                                    <td>{val.nombre_usu}</td>
                                    <td>{val.apellido_usu}</td>
                                    <td>{val.email_usu}</td>
                                    <td>{val.constrasena_usu}</td>
                                    <td>
                                        <div className='btn-group' role='group' aria-label='Basic Example'>
                                            <button type='button'
                                            onClick={()=>{
                                                editarUsu(val);
                                            }} className='btn btn-warning'>Actualizar</button>
                                            <button type='button' onClick={()=>{
                                            deleteUsuario(val);
                                            }}>Eliminar</button>
                                        </div>
                                    </td>
                                </tr>
                        }}                
            </tbody>
        </table>
      </div>
    
      <footer className="d-flex flex-column align-items-center justify-content-center">
          <p className="footer-texto text-center">El SENA quiere brindarte la mejor estadia.
              <br/>Ven, comparte y disfruta en nuestro Hotel.</p>
          <div className="iconos-redes-sociales d-flex flex-wrap align-items-center justify-content-center">
              <a href="https://web.facebook.com/sena.soacha/?locale=es_LA&_rdc=1&_rdr" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-facebook"></i>
              </a>
              <a href="https://twitter.com/SENASoacha?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-twitter"></i>
              </a>
              <a href="https://senasoachacide.blogspot.com/" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-mortarboard-fill"></i>
              </a>
              <a href="mailto:servicioalciudadano@sena.edu.co " target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-envelope"></i>
              </a>
          </div>
          <div className="derechos-de-autor">Creado por: Centro Industrial y de Desarrollo Empresarial &#169;</div> 
      </footer>
    </div>
  );
}

export default Regristrate;
