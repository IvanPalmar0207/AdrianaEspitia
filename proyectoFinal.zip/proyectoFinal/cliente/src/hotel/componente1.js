const componente1 = () =>{
    return <div>
        <h1>Hola</h1>
    </div>;
}

export default componente1;