// Dependencias generales
import React from "react";
import home1 from './css/home1.css';
import fondoRegistro from "./images/fondoRegistro.jpg";


const home = () => {
    return (      
        <div className="App">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"/>
    

        
            <section class="serviciosSection piscina">
                    <div class="container contenedor">
                    <img src={fondoRegistro} alt="ImagenDescripcion" width="380px" height="300px"/>
                    <p class="seccion-texto">El Hotel Pegasus es un verdadero oasis de lujo y comodidad en el corazón de la ciudad. Desde el momento en que cruza nuestras puertas, quedará encantado por la elegancia y el encanto que nos distingue. Nuestro hotel combina a la perfección la sofisticación contemporánea con un toque de encanto clásico, creando un ambiente acogedor y relajante para todos nuestros huéspedes.

                        Nuestras habitaciones y suites están diseñadas para proporcionar el máximo confort y privacidad. Cada una está elegantemente decorada y equipada con comodidades modernas para satisfacer todas sus necesidades. Desde las impresionantes vistas panorámicas hasta las lujosas comodidades, su estancia en el Hotel Pegasus será inolvidable.
                    </p>
                </div>
            </section>

            <footer class="d-flex flex-column align-items-center justify-content-center">
                    <p class="footer-texto text-center">El SENA quiere brindarte la mejor estadia.
                    <br/>Ven, comparte y disfruta en nuestro Hotel.</p>
                <div class="iconos-redes-sociales d-flex flex-wrap align-items-center justify-content-center">
                    <a href="https://web.facebook.com/sena.soacha/?locale=es_LA&_rdc=1&_rdr" target="_blank" rel="noopener noreferrer">
                        <i class="bi bi-facebook"></i>
                    </a>
                    <a href="https://twitter.com/SENASoacha?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" rel="noopener noreferrer">
                        <i class="bi bi-twitter"></i>
                    </a>
                    <a href="https://senasoachacide.blogspot.com/" target="_blank" rel="noopener noreferrer">
                        <i class="bi bi-mortarboard-fill"></i>
                    </a>
                    <a href="mailto:servicioalciudadano@sena.edu.co " target="_blank" rel="noopener noreferrer">
                        <i class="bi bi-envelope"></i>
                    </a>
        </div>
        <div class="derechos-de-autor">Creado por: Centro Industrial y de Desarrollo Empresarial &#169;</div> 
    </footer>
    </div>

    );
}

export default home;