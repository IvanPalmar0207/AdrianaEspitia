import { Link } from "react-router-dom";
import { Outlet } from "react-router-dom";

const iniciarSesion = () =>{
    return <div>
        <nav>
            <ul>
                <li>
                    <Link to='/'>Registrarse</Link>
                </li>
                <li>
                    <Link to='/registrarse'>Regis</Link>
                </li>
            </ul>
        </nav>
        <hr />
        <Outlet />
    </div>;
}

export default iniciarSesion;