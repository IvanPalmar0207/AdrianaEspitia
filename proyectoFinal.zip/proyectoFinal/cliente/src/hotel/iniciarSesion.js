//Importa los estilos para el archivo app.js
import './css/registrarse.css';
//Importa useState de React para manipular los datos del formulario
import{useState} from 'react';
//Importa la libreria Axios
import Axios from 'axios';
//importa Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css'
//Importa SweetAlert2
import Swal from 'sweetalert2';
//Importa los estilos
import iniciarSesion1 from './css/iniciarSesion1.css';

const IniciarSesion = () =>{
      
    //Datos y su estado
    const [numeroDocumento_usu, setNumeroDocumento] = useState("");
    const [email_usu, setEmail] = useState("");
    
    //Limpiar los formularios

    const limpiar = () => {
        setNumeroDocumento("");
        setEmail("");        
    }

    //Metodo de lectura

    const listarInicio = () => {
        Axios.put("http://localhost:3001/inicioSesion",{
            numeroDocumento_usu: numeroDocumento_usu,
            email_usu: email_usu
        }).then(()=>{
            limpiar();
            Swal.fire({
                title:"<strong> Registro exitoso! </strong>",
                html:"<i>Has iniciado sesion correctamente</i>",
                icon: "success",
                timer: 3000
            })
        }).catch(function(error){
            Swal.fire({
                icon: "error",
                title: 'Oops...',
                text: 'No se ha podido hacer el registro'
            })
        });
    }

    //Interfaz de usuario

    return (      
    <div className="App">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"/>
        <link rel='stylesheet' href={iniciarSesion1}/> 

      <section id="inicioSesion" className="bloque">
          <div className="contenido">
              <div className="formulario">
                  <div className='form'>

                      <h2>INICIAR SESION - SENA</h2>

                      <div className="info">
                          <label>Numero de documento:</label>
                          <input type="text" name="fechaLlegada" id="fechaLlegada" onChange={(event) => {setNumeroDocumento(event.target.value);}} value={numeroDocumento_usu} required/>
                      </div>

                      <div className="info">
                          <label>Correo Eletronico:</label>
                          <input type="text" name="fechaSalida" id="fechaSalida" onChange={(event) => {setEmail(event.target.value);}} value={email_usu} required/>
                      </div>

                        <div className='infoBoton'>
                            <button className='btn btnEnviar' onClick={listarInicio}>ENVIAR</button>                       
                        </div>
            
                    </div>  
                </div>
            </div>
      </section>    
    
      <footer className="d-flex flex-column align-items-center justify-content-center">
          <p className="footer-texto text-center">El SENA quiere brindarte la mejor estadia.
              <br/>Ven, comparte y disfruta en nuestro Hotel.</p>
          <div className="iconos-redes-sociales d-flex flex-wrap align-items-center justify-content-center">
              <a href="https://web.facebook.com/sena.soacha/?locale=es_LA&_rdc=1&_rdr" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-facebook"></i>
              </a>
              <a href="https://twitter.com/SENASoacha?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-twitter"></i>
              </a>
              <a href="https://senasoachacide.blogspot.com/" target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-mortarboard-fill"></i>
              </a>
              <a href="mailto:servicioalciudadano@sena.edu.co " target="_blank" rel="noopener noreferrer">
                  <i className="bi bi-envelope"></i>
              </a>
          </div>
          <div className="derechos-de-autor">Creado por: Centro Industrial y de Desarrollo Empresarial &#169;</div> 
      </footer>
    </div>
  );
}

export default IniciarSesion;