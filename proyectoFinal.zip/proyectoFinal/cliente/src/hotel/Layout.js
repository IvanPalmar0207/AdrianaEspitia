//Librerias para la renderizacion de componentes
import { Link } from "react-router-dom";
import { Outlet } from "react-router-dom";
//importa Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css'
//Importa los Estilos
import './css/layout.css';
//Importar el logo
import logoSena from './images/logoSena.png';

const Layout = () =>{
    return <div>
        <nav class="navbar navbar-expand-md navbar-light">
            <div class="container-fluid">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-toggler" aria-controls="navbar-toggler" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbar-toggler">
                <a class="navbar-brand">
                    <img src={logoSena} width="90px" alt="Logo de la pagina web"/>
                </a>
                <p>HOTELERIA CIDE</p>
                <ul class="navbar-nav d-flex justify-content-center align-items-center">
                    <li class="nav-item">
                        <Link to="home" class="nav-link" aria-current="page">INICIO</Link>
                    </li>
                    <li class="nav-item">
                        <Link to="/registrarse" class="nav-link">REGISTRO</Link>
                    </li>
                    <li class="nav-item">
                        <Link to="/iniciarSesion" class="nav-link">INICIO DE SESION</Link>
                    </li>
                    <li>
                        <Link to="/reservar" class="nav-link">RESERVAR</Link>
                    </li>
                </ul>
                  </div>
                </div>
        </nav>
        <hr />
        <Outlet />
    </div>
    ;
}

export default Layout;